package wrappers;

import org.openqa.selenium.remote.RemoteWebDriver;



public class RealWrapper {
	public RealWrapper(RemoteWebDriver driver){
		this.driver = driver;
        
   }
	
	public RemoteWebDriver
	 driver;

}

	