package testcases;


import org.testng.annotations.Test;

import realimagepages.Gmailpage;
import realimagepages.Login;
import realimagepages.Mailpage;
import realimagepages.Registerpage;
import realimagepages.Verifypage;
import wrappers.LeafTapsWrappers;

public class Testrun extends LeafTapsWrappers{
@Test	
	public void test() throws InterruptedException{
		new Login(driver)
		.logintoapp()
		.clickregister();
		Thread.sleep(3000);
		new Registerpage(driver)		
		.enteremail()
		.clickverify();
		new Gmailpage(driver)
		.loadgmai()
		.clickupdates()
		.clickmail();
		new Mailpage(driver)
		.mail();
		new Verifypage(driver)
		.enterfirstname()
		.enterlastname()
		.enterpassword()
		.confirmpasswword()
		.clickconfirm();
		
	}

}
