package realimagepages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;

public class Gmailpage extends LeafTapsWrappers{
	public Gmailpage(RemoteWebDriver driver){
		this.driver = driver;
		
	}
public Gmailpage loadgmai(){
	System.setProperty("remotewebdriver.chrome.driver", ".drivers/chromedriver.exe");
	 driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("www.gmail.com");
	return this;
	
}
public Gmailpage clickupdates(){
	driver.findElementByXPath("//div[@class='aKp aH2-aLf']").click();
	return this;
	
}
public Mailpage clickmail(){
	driver.findElementByXPath("//span[@email='noreply@qubecinema.com']").click();
	return new Mailpage(driver);
}
}
