package realimagepages;

import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;

public class Verifypage extends LeafTapsWrappers{
	public Verifypage(RemoteWebDriver driver){
		this.driver = driver;
		
	}
		public Verifypage enterfirstname(){
			driver.findElementByXPath("//input[@placeholder='Enter first name']").sendKeys("Mithra");
			return this;
		}
		
		public Verifypage enterlastname(){
			driver.findElementByXPath("//input[@placeholder='Enter last name']").sendKeys("G");
			return this;
		}
		public Verifypage enterpassword(){
			driver.findElementByXPath("//input[@placeholder='Enter password']").sendKeys("Mithra");
			return this;
		}
		public Verifypage confirmpasswword(){
			driver.findElementByXPath("//input[@placeholder='Confirm password']").sendKeys("Mithra");
			return this;
		}
		public Mobileno clickconfirm(){
			driver.findElementByXPath("//input[@class='btn btn-success btn-raised btn-block']").click();
			return new Mobileno(driver);
		}
		
}
