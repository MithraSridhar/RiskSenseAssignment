package realimagepages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;


public class Registerpage extends LeafTapsWrappers{
	

	public Registerpage(RemoteWebDriver driver){
		this.driver= driver;
System.out.println(driver.getTitle());

}
	public Registerpage enteremail(){
		//driver.findElementByXPath("//input[@placeholder='Enter email address']").clear();
		WebElement mail = driver.findElementByXPath("//input[@placeholder='Enter email address']");
		System.out.println(mail);
		mail.sendKeys("mithugopal30@gmail.com");
		return this;
		
	}
	public Gmailpage clickverify(){
		driver.findElementByXPath("//input[@class='btn btn-success btn-raised btn-block']").click();
		return new Gmailpage(driver);
	}
}
