package realimagepages;

import java.util.Set;

import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;

public class Mailpage  extends LeafTapsWrappers{
	public Mailpage(RemoteWebDriver driver){
		this.driver = driver;
		
	}
	
	public Verifypage mail(){
		driver.findElementByXPath("//a[@class='m_8648317123304119408mcnButton']").click();
		Set<String> winHandles = driver.getWindowHandles();
		for (String wHandle : winHandles) {
			driver.switchTo().window(wHandle);
			
					
		}
		return new Verifypage(driver);
		
	}
}
