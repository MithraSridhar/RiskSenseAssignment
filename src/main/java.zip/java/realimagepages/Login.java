package realimagepages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;


public class Login extends LeafTapsWrappers{
	
	

	
	public Login(RemoteWebDriver driver){
		this.driver= driver;
		
		
	}
	
	public Login logintoapp(){
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		 driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://account.staging.qube.in/login");
		return this;
		
	}
	public Registerpage clickregister(){
		driver.findElementByLinkText("Register here").click();
		return new Registerpage(driver);
	}
	

}
