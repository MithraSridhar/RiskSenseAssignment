package realimagepages;

import org.openqa.selenium.remote.RemoteWebDriver;

import wrappers.LeafTapsWrappers;

public class Mobileno  extends LeafTapsWrappers{
	public Mobileno(RemoteWebDriver driver){
		this.driver = driver;
		
	}
	

}
